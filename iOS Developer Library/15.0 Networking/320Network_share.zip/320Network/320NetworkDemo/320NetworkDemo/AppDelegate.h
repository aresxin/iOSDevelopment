//
//  AppDelegate.h
//  320NetworkDemo
//
//  Created by he baochen on 12-3-15.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate> {
  UINavigationController *_navController;
}

@property (strong, nonatomic) UIWindow *window;


@end

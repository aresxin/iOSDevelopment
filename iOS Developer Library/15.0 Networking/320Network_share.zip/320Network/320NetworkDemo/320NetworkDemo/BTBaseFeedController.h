//
//  BTGlobalFeedController.h
//  BTNetwork
//
//  Created by He baochen on 12-11-6.
//  Copyright (c) 2012年 He baochen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BTBaseFeedController : UITableViewController {
  NSMutableArray *_posts;
}

@end

//
//  BTGlobalFeedController2n.h
//  BTNetwork
//
//  Created by He baochen on 12-11-11.
//  Copyright (c) 2012年 He baochen. All rights reserved.
//

#import "BTGlobalFeedController2.h"

@interface BTGlobalFeedController2n : BTGlobalFeedController2

@end

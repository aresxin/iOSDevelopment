//
//  BTGlobalFeedController3.h
//  BTNetwork
//
//  Created by Gary on 12-11-11.
//  Copyright (c) 2012年 He baochen. All rights reserved.
//

#import "BTBaseFeedController.h"

@interface BTGlobalFeedController3 : BTBaseFeedController

@end

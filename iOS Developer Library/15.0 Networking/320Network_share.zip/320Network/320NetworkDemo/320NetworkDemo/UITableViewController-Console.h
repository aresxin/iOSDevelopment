//
//  UIViewController-Console.h
//  BTNetwork
//
//  Created by He baochen on 12-11-11.
//  Copyright (c) 2012年 He baochen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableViewController(Console)

@end

//
//  TTRequestLoader-Debug.h
//  320NetworkDemo
//
//  Created by He baochen on 12-3-17.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TTRequestLoader.h"

@interface TTRequestLoader(Debug)

@property(nonatomic, readonly) int retriesLeft;

@end

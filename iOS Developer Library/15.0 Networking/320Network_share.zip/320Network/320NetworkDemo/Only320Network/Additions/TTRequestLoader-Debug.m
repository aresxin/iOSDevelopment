//
//  TTRequestLoader-Debug.m
//  320NetworkDemo
//
//  Created by He baochen on 12-3-17.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "TTRequestLoader-Debug.h"

@implementation TTRequestLoader(Debug)

- (int) retriesLeft {
  return _retriesLeft;
}

@end

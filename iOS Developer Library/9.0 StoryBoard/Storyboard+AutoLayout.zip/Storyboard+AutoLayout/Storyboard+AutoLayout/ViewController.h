//
//  ViewController.h
//  Storyboard+AutoLayout
//
//  Created by yangjinxin on 15/2/5.
//  Copyright (c) 2015年 yangjinxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end


//
//  main.m
//  Storyboard+AutoLayout
//
//  Created by yangjinxin on 15/2/5.
//  Copyright (c) 2015年 yangjinxin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

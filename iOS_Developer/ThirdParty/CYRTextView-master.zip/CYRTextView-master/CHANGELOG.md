#CYRTextView Changelog

##0.3.0 (Sunday, January 19th, 2014)
 * Bug fixes
 * Refactored how the line cursor view is displayed
 * Cleanup

##0.2.0 (Sunday, January 5th, 2014)
 * Initial release with support for regex based syntax highlighting, line numbers, gesture based navigation.
